using Serilog;
using SondarrMerch.Core.Interfaces;
using SondarrMerch.Core.Services;
using SondarrMerch.Providers.Shopify;
using SondarrMerch.Providers.Shopify.Services;
// using SondarrMerch.Providers.WooCommerce;
// using SondarrMerch.Providers.WooCommerce.Services;

var builder = WebApplication.CreateBuilder(args);

// ── Logging ───────────────────────────────────────────────────────────────────
builder.Host.UseSerilog((ctx, cfg) =>
    cfg.ReadFrom.Configuration(ctx.Configuration).WriteTo.Console());

// ── CORS — allow Sondarr frontend + StreamingService ─────────────────────────
builder.Services.AddCors(o => o.AddPolicy("SondarrFrontend", p =>
    p.WithOrigins(
        builder.Configuration["AllowedOrigins:Frontend"] ?? "http://localhost:5173",
        builder.Configuration["AllowedOrigins:Backend"] ?? "http://localhost:5000")
     .AllowAnyHeader()
     .AllowAnyMethod()));

// ── Auth — reuse same Supabase JWT as StreamingService ────────────────────────
builder.Services.AddAuthentication("Bearer")
    .AddJwtBearer(o =>
    {
        o.Authority = builder.Configuration["Supabase:Url"];
        o.Audience = "authenticated";
    });
builder.Services.AddAuthorization();

// ── Commerce provider — swap this one line to change platforms ────────────────
//
//   Shopify  →  register ShopifyCommerceProvider   (uses Storefront GraphQL API)
//   WooComm  →  register WooCommerceProvider       (uses WC REST + Store API)
//   Custom   →  implement ICommerceProvider, register it here
//
builder.Services.Configure<ShopifySettings>(
    builder.Configuration.GetSection(ShopifySettings.Section));
builder.Services.AddHttpClient<ShopifyCommerceProvider>();
builder.Services.AddScoped<ICommerceProvider, ShopifyCommerceProvider>();

// Uncomment to switch to WooCommerce:
// builder.Services.Configure<WooCommerceSettings>(
//     builder.Configuration.GetSection(WooCommerceSettings.Section));
// builder.Services.AddHttpClient<WooCommerceProvider>();
// builder.Services.AddScoped<ICommerceProvider, WooCommerceProvider>();

// ── Core orchestration ────────────────────────────────────────────────────────
builder.Services.AddScoped<MerchService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Sondarr Merch API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new()
    {
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        Description = "Supabase JWT — same token used by the main Sondarr API."
    });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseSerilogRequestLogging();
app.UseCors("SondarrFrontend");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapGet("/health", () => Results.Ok(new { status = "ok", service = "SondarrMerch" }));

app.Run();
